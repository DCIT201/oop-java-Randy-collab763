package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MotocycleTest {
    @Test
    void testCalculateRentalCost() {
        Vehicle motocycle = new Motocycle("dog1", "Dodge", 5.0);
        assertEquals(97.0, motocycle.calculateRentalCost(2));
    }

    @Test
    void testAvailability() {
        Vehicle motorcycle = new Motocycle("dog1", "Dodge", 9.0);
        assertTrue(motorcycle.getIsAvailable());
        motorcycle.setIsAvailable(false);
        assertFalse(motorcycle.getIsAvailable());
    }
}

