package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CarTest {
    @Test
    void testCalculateRentalCost() {
        Vehicle car = new Car("cor1", "Corolla", 10.0, false);
        assertEquals(20.0, car.calculateRentalCost(2));
    }

    @Test
    void testAvailable() {
        Vehicle car = new Car("dog1", "Dodge", 10.0, true);
        assertTrue(car.getIsAvailable());
        car.setIsAvailable(false);
        assertFalse(car.getIsAvailable());
    }
}

