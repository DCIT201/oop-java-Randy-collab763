package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RentalTransactionTest {
    private RentalTransaction trans;
    private Customer cus;
    private Vehicle vc;

    @BeforeEach
    void setUp() {
        // Create a customer and a vehicle for testing
        cus = new Customer("Randy", 56);
        vc = new Car("civ1", "Civic", 10.0, false);
        trans = new RentalTransaction("(ID)1", cus, vc);
    }

    @Test
    void testTransactionInitialization() {
        assertEquals("(ID)1", trans.getTransactionId());
        assertEquals(cus, trans.getCustomer());
        assertEquals(vc, trans.getVehicle());
        assertFalse(trans.isCompleted());
    }

    @Test
    void testSetIsCompleted() {
        trans.setCompleted();
        assertTrue(trans.isCompleted());
        assertTrue(vc.getIsAvailable());
    }
}
