package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TruckTest {
    @Test
    void testCalculateRentalCost() {
        Vehicle car = new Truck("C1", "Renault", 10.0);
        assertEquals(100000.0, car.calculateRentalCost(10));
    }

    @Test
    void testAvailability() {
        Vehicle truck = new Truck("mar1", "Marcopolo", 32);
        assertTrue(truck.getIsAvailable());
        truck.setIsAvailable(false);
        assertFalse(truck.getIsAvailable());
    }
}

